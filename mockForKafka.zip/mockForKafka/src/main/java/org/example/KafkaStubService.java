package org.example;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.concurrent.atomic.AtomicLong;

// проверить логгирование
//

@Service
public class KafkaStubService {
    private final KafkaMessageRepository repository;
    private final ObjectMapper mapper = new ObjectMapper();
    private final AtomicLong delayMs = new AtomicLong(1000); // начальная задержка
    public KafkaStubService(KafkaMessageRepository repository) {
        this.repository = repository;
    }

    @Async
    @KafkaListener(topics = "mainTopic", groupId = "stub-consumer-group")
    public void listen(String message) throws Exception {
        JsonNode node = mapper.readTree(message);

        String msgUuid = node.get("msg_uuid").asText();
        boolean head = node.get("head").asBoolean();

        System.out.println(Instant.now() + " – [Read from Kafka] " + message);

        Thread.sleep(delayMs.get());

        KafkaMessage dbRecord = new KafkaMessage();
        dbRecord.setMsgUuid(msgUuid);
        dbRecord.setHead(head);
        dbRecord.setTimeRq(Instant.now().getEpochSecond());
        repository.save(dbRecord);

        System.out.println(Instant.now() + " – [Write to DB] { \"msgUuid\": \"" + msgUuid +
                "\", \"head\": " + head + ", \"timeRq\": \"" + dbRecord.getTimeRq() + "\" }");
    }

    public void setDelay(long delay) {
        delayMs.set(delay);
        System.out.println("Delay updated to " + delay + "ms");
    }
}


package org.example;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/config")
public class DelayController {
    private final KafkaStubService service;
    public DelayController(KafkaStubService service) {
        this.service = service;
    }

    @PostMapping("/delay")
    public String setDelay(@RequestParam long ms) {
        service.setDelay(ms);
        return "Delay updated to " + ms + "ms";
    }
}


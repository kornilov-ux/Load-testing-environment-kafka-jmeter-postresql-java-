package org.example;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class KafkaMessage {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String msgUuid;
    private Boolean head;
    private Long timeRq;

    // геттеры и сеттеры
    public String getMsgUuid() { return msgUuid; }
    public void setMsgUuid(String msgUuid) { this.msgUuid = msgUuid; }
    public Boolean getHead() { return head; }
    public void setHead(Boolean head) { this.head = head; }
    public Long getTimeRq() { return timeRq; }
    public void setTimeRq(Long timeRq) { this.timeRq = timeRq; }
}
